<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Halaman Login</title>
	<link href="<?= base_url('public/template/css/bootstrap.min.css'); ?>" rel="stylesheet">
	<style>
		.error {
			color: red;
			font-size: 0.9em;
		}
		.success {
			color: green;
			font-size: 0.9em;
		}
	</style>
</head>

<body>
	<div class="row justify-content-center pt-5">
		<div class="card col-md-4">
			<div class="card-header">
				<div class="card-title fw-bold">Sign In</div>
			</div>
			<div class="card-body">
				<form id="loginForm" action="#" method="post" enctype="multipart/form-data">
					<div class="mb-3">
						<label for="email" class="form-label">Email</label>
						<input type="email" class="form-control" id="email" name="email" value="">
						<div id="emailError" class="error"></div>
					</div>
					<div class="mb-3">
						<label for="password" class="form-label">Password</label>
						<input type="password" class="form-control" id="password" name="password" value="">
						<div id="passwordError" class="error"></div>
					</div>

					<button type="button" id="loginBtn" class="btn btn-primary">Login</button>
					<div id="loginSuccess" class="success mt-3"></div>
				</form>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
	<script>
		$(document).ready(function () {
			$('#loginBtn').click(function () {
				
				$('#emailError').text('');
				$('#passwordError').text('');
				$('#loginSuccess').text('');

				const email = $('#email').val().trim();
				const password = $('#password').val().trim();
				let hasError = false;

				
				if (!email) {
					$('#emailError').text('Email harus diisi');
					hasError = true;
				}

				
				if (!password) {
					$('#passwordError').text('Password harus diisi');
					hasError = true;
				}

				
				if (!hasError) {
				
					setTimeout(() => {
						const response = { status: true }; 
						if (response.status) {
							$('#loginSuccess').html(`
								Login berhasil!<br>
								Email anda: ${email}<br>
								Password anda: ${password}
							`);
							$('#loginBtn').text('Logout').addClass('btn-danger').removeClass('btn-primary');
						} else {
							$('#loginSuccess').text('Login gagal. Periksa email dan password.');
						}
					}, 500); 
				}
			});
		});
	</script>
</body>

</html>
